# ZepkarHUDTweaker v2.1 (fixed source)

Fabric 1.21.4 client mod source.

Included:
- Smooth rectangle health HUD
- Food HUD
- Armor durability HUD (shows armor items + durability left + mini bar)
- Drag mode in GUI
- Right Shift opens editor

What changed in this fixed source:
- Removed the held-item mixin from the build so the project is easier to compile on Fabric 1.21.4
- Added `gradlew.bat` / `gradlew` bootstrap scripts that download Gradle 8.14 automatically on first run

## Build
Windows PowerShell:

```powershell
cd "path\to\ZepkarHUDTweaker-v2-fixed"
.\gradlew.bat build
```

Linux/macOS:

```bash
./gradlew build
```

Output jar:
- `build/libs/ZepkarHUDTweaker-2.0.0.jar`

## Notes
- This fixed source focuses on the draggable HUD and armor durability UI.
- The held-item animation editor scaffold was removed from the active build because that mixin is the part most likely to break across mappings.
