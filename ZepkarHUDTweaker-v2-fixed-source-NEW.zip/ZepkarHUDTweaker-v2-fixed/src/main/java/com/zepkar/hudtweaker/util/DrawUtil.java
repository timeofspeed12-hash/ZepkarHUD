package com.zepkar.hudtweaker.util;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

public final class DrawUtil {
    private DrawUtil() {}

    public static void roundedBar(DrawContext ctx, int x, int y, int w, int h, float progress, int bg, int fg) {
        progress = MathHelper.clamp(progress, 0.0f, 1.0f);
        ctx.fill(x, y, x + w, y + h, bg);
        ctx.fill(x, y, x + Math.max(1, (int) (w * progress)), y + h, fg);
    }
}
