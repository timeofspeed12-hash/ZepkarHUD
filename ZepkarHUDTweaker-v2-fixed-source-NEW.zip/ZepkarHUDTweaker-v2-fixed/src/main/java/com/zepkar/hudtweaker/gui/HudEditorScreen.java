package com.zepkar.hudtweaker.gui;

import com.zepkar.hudtweaker.ZepkarHUDTweakerClient;
import com.zepkar.hudtweaker.config.ModConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class HudEditorScreen extends Screen {
    private final Screen parent;
    private DragTarget dragging = DragTarget.NONE;
    private int dragOffsetX;
    private int dragOffsetY;

    private enum DragTarget { NONE, HEALTH, FOOD, ARMOR }

    public HudEditorScreen(Screen parent) {
        super(Text.literal("ZepkarHUDTweaker"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ModConfig cfg = ZepkarHUDTweakerClient.CONFIG;
        addDrawableChild(ButtonWidget.builder(Text.literal("Drag: " + (cfg.dragMode ? "ON" : "OFF")), b -> {
            cfg.dragMode = !cfg.dragMode;
            b.setMessage(Text.literal("Drag: " + (cfg.dragMode ? "ON" : "OFF")));
            ZepkarHUDTweakerClient.save();
        }).dimensions(10, 10, 90, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Health " + onOff(cfg.health.enabled)), b -> {
            cfg.health.enabled = !cfg.health.enabled;
            b.setMessage(Text.literal("Health " + onOff(cfg.health.enabled)));
            ZepkarHUDTweakerClient.save();
        }).dimensions(10, 38, 90, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Food " + onOff(cfg.food.enabled)), b -> {
            cfg.food.enabled = !cfg.food.enabled;
            b.setMessage(Text.literal("Food " + onOff(cfg.food.enabled)));
            ZepkarHUDTweakerClient.save();
        }).dimensions(10, 66, 90, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Armor " + onOff(cfg.armor.enabled)), b -> {
            cfg.armor.enabled = !cfg.armor.enabled;
            b.setMessage(Text.literal("Armor " + onOff(cfg.armor.enabled)));
            ZepkarHUDTweakerClient.save();
        }).dimensions(10, 94, 90, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close()).dimensions(width - 80, 10, 70, 20).build());
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        ZepkarHUDTweakerClient.save();
        client.setScreen(parent);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && ZepkarHUDTweakerClient.CONFIG.dragMode) {
            ModConfig cfg = ZepkarHUDTweakerClient.CONFIG;
            if (inside(mouseX, mouseY, cfg.health.x, cfg.health.y, cfg.health.width, cfg.health.height)) {
                dragging = DragTarget.HEALTH;
                dragOffsetX = (int) mouseX - cfg.health.x;
                dragOffsetY = (int) mouseY - cfg.health.y;
                return true;
            }
            if (inside(mouseX, mouseY, cfg.food.x, cfg.food.y, cfg.food.width, cfg.food.height)) {
                dragging = DragTarget.FOOD;
                dragOffsetX = (int) mouseX - cfg.food.x;
                dragOffsetY = (int) mouseY - cfg.food.y;
                return true;
            }
            if (inside(mouseX, mouseY, cfg.armor.x, cfg.armor.y, 92, 36)) {
                dragging = DragTarget.ARMOR;
                dragOffsetX = (int) mouseX - cfg.armor.x;
                dragOffsetY = (int) mouseY - cfg.armor.y;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        ModConfig cfg = ZepkarHUDTweakerClient.CONFIG;
        if (button == 0) {
            switch (dragging) {
                case HEALTH -> {
                    cfg.health.x = (int) mouseX - dragOffsetX;
                    cfg.health.y = (int) mouseY - dragOffsetY;
                    return true;
                }
                case FOOD -> {
                    cfg.food.x = (int) mouseX - dragOffsetX;
                    cfg.food.y = (int) mouseY - dragOffsetY;
                    return true;
                }
                case ARMOR -> {
                    cfg.armor.x = (int) mouseX - dragOffsetX;
                    cfg.armor.y = (int) mouseY - dragOffsetY;
                    return true;
                }
            }
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            dragging = DragTarget.NONE;
            ZepkarHUDTweakerClient.save();
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawText(textRenderer, title, 12, height - 22, 0xFFFFFFFF, true);
        context.drawText(textRenderer, Text.literal("Liquid-like preview + drag mode"), 110, 16, 0xFFCDE7FF, false);
        context.drawText(textRenderer, Text.literal("Health/Food/Armor are draggable"), 110, 30, 0xFFAED8FF, false);
        super.render(context, mouseX, mouseY, delta);
    }

    private static String onOff(boolean v) { return v ? "ON" : "OFF"; }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }
}
