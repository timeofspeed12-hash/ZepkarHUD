package com.zepkar.hudtweaker.config;

public class ModConfig {
    public HudBox health = new HudBox(16, 16, 150, 12, true);
    public HudBox food = new HudBox(16, 34, 150, 10, true);
    public ArmorHud armor = new ArmorHud();
    public ItemAnim mainHand = new ItemAnim();
    public ItemAnim offHand = new ItemAnim();
    public boolean dragMode = false;
    public float animationSmoothness = 0.16f;

    public static class HudBox {
        public int x;
        public int y;
        public int width;
        public int height;
        public boolean enabled;

        public HudBox(int x, int y, int width, int height, boolean enabled) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.enabled = enabled;
        }

        public HudBox() {}
    }

    public static class ArmorHud {
        public int x = 16;
        public int y = 52;
        public float scale = 1.0f;
        public boolean enabled = true;
        public String durabilityMode = "VALUE_AND_BAR";
    }

    public static class ItemAnim {
        public boolean enabled = true;
        public String mode = "SMOOTH";
        public float scale = 1.0f;
        public float offsetX = 0.0f;
        public float offsetY = 0.0f;
        public float offsetZ = 0.0f;
        public float rotX = 0.0f;
        public float rotY = 0.0f;
        public float rotZ = 0.0f;
        public float swingSpeed = 1.0f;
    }
}
