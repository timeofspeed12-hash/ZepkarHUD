package com.zepkar.hudtweaker.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.zepkar.hudtweaker.ZepkarHUDTweakerClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("zepkarhudtweaker.json");

    private ConfigManager() {}

    public static ModConfig load() {
        try {
            if (Files.exists(PATH)) {
                return GSON.fromJson(Files.readString(PATH), ModConfig.class);
            }
        } catch (Exception ignored) {
        }
        ModConfig cfg = new ModConfig();
        save(cfg);
        return cfg;
    }

    public static void save(ModConfig config) {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(config));
        } catch (IOException e) {
            System.err.println("[" + ZepkarHUDTweakerClient.MOD_ID + "] Failed to save config: " + e.getMessage());
        }
    }
}
