package com.zepkar.hudtweaker;

import com.zepkar.hudtweaker.config.ConfigManager;
import com.zepkar.hudtweaker.config.ModConfig;
import com.zepkar.hudtweaker.gui.HudEditorScreen;
import com.zepkar.hudtweaker.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ZepkarHUDTweakerClient implements ClientModInitializer {
    public static final String MOD_ID = "zepkarhudtweaker";
    public static ModConfig CONFIG;
    public static KeyBinding OPEN_EDITOR;

    @Override
    public void onInitializeClient() {
        CONFIG = ConfigManager.load();
        OPEN_EDITOR = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zepkarhudtweaker.editor",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.zepkarhudtweaker"
        ));

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null && !client.options.hudHidden) {
                HudRenderer.render(drawContext, tickDelta);
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_EDITOR.wasPressed()) {
                client.setScreen(new HudEditorScreen(null));
            }
        });
    }

    public static void save() {
        ConfigManager.save(CONFIG);
    }
}
