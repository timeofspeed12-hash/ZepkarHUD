package com.zepkar.hudtweaker.hud;

import com.zepkar.hudtweaker.ZepkarHUDTweakerClient;
import com.zepkar.hudtweaker.config.ModConfig;
import com.zepkar.hudtweaker.util.DrawUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

public final class HudRenderer {
    private static float healthDisplay = -1;
    private static float foodDisplay = -1;

    private HudRenderer() {}

    public static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) return;

        ModConfig cfg = ZepkarHUDTweakerClient.CONFIG;

        if (cfg.health.enabled) {
            float actual = player.getHealth() / player.getMaxHealth();
            healthDisplay = animate(healthDisplay < 0 ? actual : healthDisplay, actual, cfg.animationSmoothness);
            DrawUtil.roundedBar(ctx, cfg.health.x, cfg.health.y, cfg.health.width, cfg.health.height, healthDisplay, 0x90000000, 0xFF47B2FF);
            ctx.drawText(client.textRenderer, String.format("HP %.1f", player.getHealth()), cfg.health.x + 4, cfg.health.y - 10, 0xFFFFFFFF, true);
        }

        if (cfg.food.enabled) {
            float actual = player.getHungerManager().getFoodLevel() / 20.0f;
            foodDisplay = animate(foodDisplay < 0 ? actual : foodDisplay, actual, cfg.animationSmoothness);
            DrawUtil.roundedBar(ctx, cfg.food.x, cfg.food.y, cfg.food.width, cfg.food.height, foodDisplay, 0x90000000, 0xFFFFC14D);
            ctx.drawText(client.textRenderer, "Food " + player.getHungerManager().getFoodLevel(), cfg.food.x + 4, cfg.food.y - 10, 0xFFFFFFFF, true);
        }

        if (cfg.armor.enabled) {
            renderArmorDurability(ctx, client, cfg);
        }

        if (cfg.dragMode) {
            drawDragBounds(ctx, cfg);
        }
    }

    private static void renderArmorDurability(DrawContext ctx, MinecraftClient client, ModConfig cfg) {
        int x = cfg.armor.x;
        int y = cfg.armor.y;
        int slot = 0;
        for (ItemStack stack : client.player.getArmorItems()) {
            int drawX = x + (slot * 22);
            ctx.drawItem(stack, drawX, y);
            if (!stack.isEmpty() && stack.isDamageable()) {
                int max = stack.getMaxDamage();
                int left = max - stack.getDamage();
                float pct = left / (float) max;
                ctx.drawText(client.textRenderer, String.valueOf(left), drawX - 1, y + 18, 0xFFFFFFFF, true);
                DrawUtil.roundedBar(ctx, drawX - 1, y + 28, 18, 3, pct, 0x90000000, 0xFF63FF8B);
            }
            slot++;
        }
        ctx.drawText(client.textRenderer, "Armor Durability", x, y - 10, 0xFFCDE7FF, true);
    }

    private static void drawDragBounds(DrawContext ctx, ModConfig cfg) {
        ctx.drawBorder(cfg.health.x - 2, cfg.health.y - 2, cfg.health.width + 4, cfg.health.height + 4, 0xFFFFFFFF);
        ctx.drawBorder(cfg.food.x - 2, cfg.food.y - 2, cfg.food.width + 4, cfg.food.height + 4, 0xFFFFFFFF);
        ctx.drawBorder(cfg.armor.x - 3, cfg.armor.y - 3, 92, 36, 0xFFFFFFFF);
    }

    private static float animate(float from, float to, float speed) {
        return from + (to - from) * speed;
    }
}
