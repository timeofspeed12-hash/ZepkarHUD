@echo off
setlocal ENABLEDELAYEDEXPANSION
set "ROOT=%~dp0"
set "BOOT_DIR=%ROOT%.gradle-bootstrap"
set "DIST_NAME=gradle-8.14-bin.zip"
set "DIST_URL=https://services.gradle.org/distributions/%DIST_NAME%"
set "DIST_ZIP=%BOOT_DIR%\%DIST_NAME%"
set "DIST_DIR=%BOOT_DIR%\gradle-8.14"
set "GRADLE_EXE=%DIST_DIR%\bin\gradle.bat"

if not exist "%BOOT_DIR%" mkdir "%BOOT_DIR%"

if not exist "%GRADLE_EXE%" (
  echo Downloading Gradle 8.14...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%DIST_URL%' -OutFile '%DIST_ZIP%'"
  if errorlevel 1 exit /b 1
  echo Extracting Gradle...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%DIST_ZIP%' -DestinationPath '%BOOT_DIR%' -Force"
  if errorlevel 1 exit /b 1
)

call "%GRADLE_EXE%" -p "%ROOT%" %*
endlocal
